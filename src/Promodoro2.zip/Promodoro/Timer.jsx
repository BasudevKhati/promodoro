import React from "react"
import './style.css'
import { useState } from "react"
// import { useRef } from "react";
import { useEffect } from "react";
import { Helmet } from "react-helmet";


export const Timer = () => {

    const [value, setValue] = useState(51);
    const [time, setTime] = useState(0);
    const [isActive, setIsActive] = useState(true);
    const [description, setDescription] = useState('Please choose your schedule !!')

    const handleRangeChange = (e) => {
        setValue(e.target.value)
    }

    useEffect(() => {
        if (isActive && time > 0) {
            const interval = setInterval(() => {
                setTime((time) => time - 1)
            }, 1000)
            return () => clearInterval(interval)
        }
    }, [time,  isActive])

    const getTime = (time) => {
        
        const minute = Math.floor(time / 60);
        const second = time % 60;

        return `${minute < 10 ? "0" + minute : minute } : ${second < 10 ? "0" + second : second }`
    }
    
    const handlePlayButton = () => {
        setIsActive(true);
    }
    
    const handlePauseButton = () => {
        setIsActive(false);
    }

    const handleCodeTime = () => {
        setTime(30 * 60);
        setDescription('The Code Time');
    }

    const handleSocialTime = () => {
        setTime(5 * 60)
        setDescription('The Social Time');
    }

    const handleCoffeeTime = () => {
        setTime(15 * 60);
        setDescription('The Coffee Time')
    }

    return (
        <>
        <Helmet>
            <title>  {getTime(time)} | Promodoro App</title>
        </Helmet>
        <section className="timer-page">
            <div className="page-wrapper">
                <div className="middle-content">
                    <div className="time">
                        <span> {getTime(time)}  </span>
                    </div>
                    <div className="time-detail">
                        <p>{description}</p>
                    </div>
                    <div className="time-but">
                        <button onClick={handleCodeTime}>
                            Code
                        </button>
                        <button onClick={handleSocialTime}>
                            Social
                        </button>
                        <button onClick={handleCoffeeTime}>
                            Coffee
                        </button>
                    </div>
                    <div className="play-pause">
                        <button onClick={handlePlayButton}>
                            <i class="fa fa-play-circle" aria-hidden="true"></i>
                        </button>
                        <button onClick={handlePauseButton}>
                            <i class="fa fa-pause-circle" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div className="footer">
                <div className="footer-status">
                    <div className="about">
                        <a href="https://en.wikipedia.org/wiki/Pomodoro_Technique">What is Pomodoro?</a>
                    </div>
                    <div className="check-boxes">
                        <div className="check-input">
                            <label>
                                <input type="checkbox" name="myCheckbox" /> Notification
                            </label>
                            <label>
                                <input type="checkbox" name="myCheckbox" /> Sound
                            </label>
                            <label>
                                <input type="checkbox" name="myCheckbox" /> Vibration
                            </label>
                        </div>
                        <div className="volume-check">
                            <i class="fa fa-volume-off" aria-hidden="true"></i>
                            <label>
                                <input type="range" step='1' min='0' max='100' id="volume" value={value} onChange={handleRangeChange} />
                            </label>
                        </div>
                    </div>
                </div>
                <div className="footer-copyright">
                    <p>&copy;2023 by Google Lense  - All Rights Reserve. </p>
                </div>
            </div>
        </section>
        </>
    )

}